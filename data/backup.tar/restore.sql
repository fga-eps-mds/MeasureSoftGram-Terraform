--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1 (Debian 15.1-1.pgdg110+1)
-- Dumped by pg_dump version 15.1 (Debian 15.1-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO postgres;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_emailaddress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailaddress_id_seq OWNER TO postgres;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_emailaddress_id_seq OWNED BY public.account_emailaddress.id;


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO postgres;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.account_emailconfirmation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.account_emailconfirmation_id_seq OWNER TO postgres;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.account_emailconfirmation_id_seq OWNED BY public.account_emailconfirmation.id;


--
-- Name: accounts_customuser; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_customuser (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150),
    last_name character varying(150),
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.accounts_customuser OWNER TO postgres;

--
-- Name: accounts_customuser_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_customuser_groups (
    id bigint NOT NULL,
    customuser_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.accounts_customuser_groups OWNER TO postgres;

--
-- Name: accounts_customuser_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_customuser_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_customuser_groups_id_seq OWNER TO postgres;

--
-- Name: accounts_customuser_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_customuser_groups_id_seq OWNED BY public.accounts_customuser_groups.id;


--
-- Name: accounts_customuser_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_customuser_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_customuser_id_seq OWNER TO postgres;

--
-- Name: accounts_customuser_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_customuser_id_seq OWNED BY public.accounts_customuser.id;


--
-- Name: accounts_customuser_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts_customuser_user_permissions (
    id bigint NOT NULL,
    customuser_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.accounts_customuser_user_permissions OWNER TO postgres;

--
-- Name: accounts_customuser_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.accounts_customuser_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_customuser_user_permissions_id_seq OWNER TO postgres;

--
-- Name: accounts_customuser_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.accounts_customuser_user_permissions_id_seq OWNED BY public.accounts_customuser_user_permissions.id;


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO postgres;

--
-- Name: characteristics_calculatedcharacteristic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.characteristics_calculatedcharacteristic (
    id bigint NOT NULL,
    value double precision NOT NULL,
    created_at timestamp with time zone NOT NULL,
    characteristic_id bigint NOT NULL,
    repository_id bigint NOT NULL
);


ALTER TABLE public.characteristics_calculatedcharacteristic OWNER TO postgres;

--
-- Name: characteristics_calculatedcharacteristic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.characteristics_calculatedcharacteristic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.characteristics_calculatedcharacteristic_id_seq OWNER TO postgres;

--
-- Name: characteristics_calculatedcharacteristic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.characteristics_calculatedcharacteristic_id_seq OWNED BY public.characteristics_calculatedcharacteristic.id;


--
-- Name: characteristics_supportedcharacteristic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.characteristics_supportedcharacteristic (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    key character varying(128) NOT NULL,
    description text
);


ALTER TABLE public.characteristics_supportedcharacteristic OWNER TO postgres;

--
-- Name: characteristics_supportedcharacteristic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.characteristics_supportedcharacteristic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.characteristics_supportedcharacteristic_id_seq OWNER TO postgres;

--
-- Name: characteristics_supportedcharacteristic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.characteristics_supportedcharacteristic_id_seq OWNED BY public.characteristics_supportedcharacteristic.id;


--
-- Name: characteristics_supportedcharacteristic_subcharacteristics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.characteristics_supportedcharacteristic_subcharacteristics (
    id bigint NOT NULL,
    supportedcharacteristic_id bigint NOT NULL,
    supportedsubcharacteristic_id bigint NOT NULL
);


ALTER TABLE public.characteristics_supportedcharacteristic_subcharacteristics OWNER TO postgres;

--
-- Name: characteristics_supportedcharacteristic_subcharacteristi_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.characteristics_supportedcharacteristic_subcharacteristi_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.characteristics_supportedcharacteristic_subcharacteristi_id_seq OWNER TO postgres;

--
-- Name: characteristics_supportedcharacteristic_subcharacteristi_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.characteristics_supportedcharacteristic_subcharacteristi_id_seq OWNED BY public.characteristics_supportedcharacteristic_subcharacteristics.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_admin_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: goals_goal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.goals_goal (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    start_at timestamp with time zone NOT NULL,
    end_at timestamp with time zone NOT NULL,
    release_name character varying(255) NOT NULL,
    data jsonb NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.goals_goal OWNER TO postgres;

--
-- Name: goals_goal_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.goals_goal_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.goals_goal_id_seq OWNER TO postgres;

--
-- Name: goals_goal_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.goals_goal_id_seq OWNED BY public.goals_goal.id;


--
-- Name: measures_calculatedmeasure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.measures_calculatedmeasure (
    id bigint NOT NULL,
    value double precision NOT NULL,
    created_at timestamp with time zone NOT NULL,
    measure_id bigint NOT NULL,
    repository_id bigint NOT NULL
);


ALTER TABLE public.measures_calculatedmeasure OWNER TO postgres;

--
-- Name: measures_calculatedmeasure_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.measures_calculatedmeasure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.measures_calculatedmeasure_id_seq OWNER TO postgres;

--
-- Name: measures_calculatedmeasure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.measures_calculatedmeasure_id_seq OWNED BY public.measures_calculatedmeasure.id;


--
-- Name: measures_supportedmeasure; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.measures_supportedmeasure (
    id bigint NOT NULL,
    key character varying(128) NOT NULL,
    name character varying(128) NOT NULL,
    description text
);


ALTER TABLE public.measures_supportedmeasure OWNER TO postgres;

--
-- Name: measures_supportedmeasure_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.measures_supportedmeasure_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.measures_supportedmeasure_id_seq OWNER TO postgres;

--
-- Name: measures_supportedmeasure_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.measures_supportedmeasure_id_seq OWNED BY public.measures_supportedmeasure.id;


--
-- Name: measures_supportedmeasure_metrics; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.measures_supportedmeasure_metrics (
    id bigint NOT NULL,
    supportedmeasure_id bigint NOT NULL,
    supportedmetric_id bigint NOT NULL
);


ALTER TABLE public.measures_supportedmeasure_metrics OWNER TO postgres;

--
-- Name: measures_supportedmeasure_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.measures_supportedmeasure_metrics_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.measures_supportedmeasure_metrics_id_seq OWNER TO postgres;

--
-- Name: measures_supportedmeasure_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.measures_supportedmeasure_metrics_id_seq OWNED BY public.measures_supportedmeasure_metrics.id;


--
-- Name: metrics_collectedmetric; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.metrics_collectedmetric (
    id bigint NOT NULL,
    value double precision NOT NULL,
    path character varying(255),
    qualifier character varying(5),
    dynamic_key character varying(128),
    created_at timestamp with time zone NOT NULL,
    metric_id bigint NOT NULL,
    repository_id bigint NOT NULL
);


ALTER TABLE public.metrics_collectedmetric OWNER TO postgres;

--
-- Name: metrics_collectedmetric_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.metrics_collectedmetric_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metrics_collectedmetric_id_seq OWNER TO postgres;

--
-- Name: metrics_collectedmetric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.metrics_collectedmetric_id_seq OWNED BY public.metrics_collectedmetric.id;


--
-- Name: metrics_supportedmetric; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.metrics_supportedmetric (
    id bigint NOT NULL,
    key character varying(128) NOT NULL,
    metric_type character varying(15) NOT NULL,
    name character varying(128) NOT NULL,
    description text
);


ALTER TABLE public.metrics_supportedmetric OWNER TO postgres;

--
-- Name: metrics_supportedmetric_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.metrics_supportedmetric_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.metrics_supportedmetric_id_seq OWNER TO postgres;

--
-- Name: metrics_supportedmetric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.metrics_supportedmetric_id_seq OWNED BY public.metrics_supportedmetric.id;


--
-- Name: organizations_organization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations_organization (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    key character varying(128) NOT NULL,
    description text
);


ALTER TABLE public.organizations_organization OWNER TO postgres;

--
-- Name: organizations_organization_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_organization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizations_organization_id_seq OWNER TO postgres;

--
-- Name: organizations_organization_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_organization_id_seq OWNED BY public.organizations_organization.id;


--
-- Name: organizations_organization_members; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations_organization_members (
    id bigint NOT NULL,
    organization_id bigint NOT NULL,
    customuser_id bigint NOT NULL
);


ALTER TABLE public.organizations_organization_members OWNER TO postgres;

--
-- Name: organizations_organization_members_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_organization_members_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizations_organization_members_id_seq OWNER TO postgres;

--
-- Name: organizations_organization_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_organization_members_id_seq OWNED BY public.organizations_organization_members.id;


--
-- Name: organizations_product; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations_product (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    key character varying(128) NOT NULL,
    description text,
    organization_id bigint NOT NULL
);


ALTER TABLE public.organizations_product OWNER TO postgres;

--
-- Name: organizations_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_product_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizations_product_id_seq OWNER TO postgres;

--
-- Name: organizations_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_product_id_seq OWNED BY public.organizations_product.id;


--
-- Name: organizations_repository; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.organizations_repository (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    key character varying(128) NOT NULL,
    description text,
    product_id bigint NOT NULL
);


ALTER TABLE public.organizations_repository OWNER TO postgres;

--
-- Name: organizations_repository_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.organizations_repository_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.organizations_repository_id_seq OWNER TO postgres;

--
-- Name: organizations_repository_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.organizations_repository_id_seq OWNED BY public.organizations_repository.id;


--
-- Name: pre_configs_preconfig; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pre_configs_preconfig (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    name character varying(128),
    data jsonb NOT NULL,
    product_id bigint NOT NULL
);


ALTER TABLE public.pre_configs_preconfig OWNER TO postgres;

--
-- Name: pre_configs_preconfig_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pre_configs_preconfig_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pre_configs_preconfig_id_seq OWNER TO postgres;

--
-- Name: pre_configs_preconfig_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pre_configs_preconfig_id_seq OWNED BY public.pre_configs_preconfig.id;


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data text NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO postgres;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.socialaccount_socialaccount_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialaccount_id_seq OWNER TO postgres;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.socialaccount_socialaccount_id_seq OWNED BY public.socialaccount_socialaccount.id;


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO postgres;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.socialaccount_socialapp_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_id_seq OWNER TO postgres;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.socialaccount_socialapp_id_seq OWNED BY public.socialaccount_socialapp.id;


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id bigint NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO postgres;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.socialaccount_socialapp_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialapp_sites_id_seq OWNER TO postgres;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.socialaccount_socialapp_sites_id_seq OWNED BY public.socialaccount_socialapp_sites.id;


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO postgres;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.socialaccount_socialtoken_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.socialaccount_socialtoken_id_seq OWNER TO postgres;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.socialaccount_socialtoken_id_seq OWNED BY public.socialaccount_socialtoken.id;


--
-- Name: sqc_sqc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sqc_sqc (
    id bigint NOT NULL,
    value double precision NOT NULL,
    created_at timestamp with time zone NOT NULL,
    repository_id bigint NOT NULL
);


ALTER TABLE public.sqc_sqc OWNER TO postgres;

--
-- Name: sqc_sqc_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sqc_sqc_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sqc_sqc_id_seq OWNER TO postgres;

--
-- Name: sqc_sqc_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sqc_sqc_id_seq OWNED BY public.sqc_sqc.id;


--
-- Name: subcharacteristics_calculatedsubcharacteristic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subcharacteristics_calculatedsubcharacteristic (
    id bigint NOT NULL,
    value double precision NOT NULL,
    created_at timestamp with time zone NOT NULL,
    repository_id bigint NOT NULL,
    subcharacteristic_id bigint NOT NULL
);


ALTER TABLE public.subcharacteristics_calculatedsubcharacteristic OWNER TO postgres;

--
-- Name: subcharacteristics_calculatedsubcharacteristic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subcharacteristics_calculatedsubcharacteristic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subcharacteristics_calculatedsubcharacteristic_id_seq OWNER TO postgres;

--
-- Name: subcharacteristics_calculatedsubcharacteristic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subcharacteristics_calculatedsubcharacteristic_id_seq OWNED BY public.subcharacteristics_calculatedsubcharacteristic.id;


--
-- Name: subcharacteristics_supportedsubcharacteristic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subcharacteristics_supportedsubcharacteristic (
    id bigint NOT NULL,
    name character varying(128) NOT NULL,
    key character varying(128) NOT NULL,
    description text
);


ALTER TABLE public.subcharacteristics_supportedsubcharacteristic OWNER TO postgres;

--
-- Name: subcharacteristics_supportedsubcharacteristic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subcharacteristics_supportedsubcharacteristic_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subcharacteristics_supportedsubcharacteristic_id_seq OWNER TO postgres;

--
-- Name: subcharacteristics_supportedsubcharacteristic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subcharacteristics_supportedsubcharacteristic_id_seq OWNED BY public.subcharacteristics_supportedsubcharacteristic.id;


--
-- Name: subcharacteristics_supportedsubcharacteristic_measures; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subcharacteristics_supportedsubcharacteristic_measures (
    id bigint NOT NULL,
    supportedsubcharacteristic_id bigint NOT NULL,
    supportedmeasure_id bigint NOT NULL
);


ALTER TABLE public.subcharacteristics_supportedsubcharacteristic_measures OWNER TO postgres;

--
-- Name: subcharacteristics_supportedsubcharacteristic_measures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.subcharacteristics_supportedsubcharacteristic_measures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subcharacteristics_supportedsubcharacteristic_measures_id_seq OWNER TO postgres;

--
-- Name: subcharacteristics_supportedsubcharacteristic_measures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.subcharacteristics_supportedsubcharacteristic_measures_id_seq OWNED BY public.subcharacteristics_supportedsubcharacteristic_measures.id;


--
-- Name: account_emailaddress id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress ALTER COLUMN id SET DEFAULT nextval('public.account_emailaddress_id_seq'::regclass);


--
-- Name: account_emailconfirmation id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation ALTER COLUMN id SET DEFAULT nextval('public.account_emailconfirmation_id_seq'::regclass);


--
-- Name: accounts_customuser id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser ALTER COLUMN id SET DEFAULT nextval('public.accounts_customuser_id_seq'::regclass);


--
-- Name: accounts_customuser_groups id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_groups ALTER COLUMN id SET DEFAULT nextval('public.accounts_customuser_groups_id_seq'::regclass);


--
-- Name: accounts_customuser_user_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.accounts_customuser_user_permissions_id_seq'::regclass);


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: characteristics_calculatedcharacteristic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_calculatedcharacteristic ALTER COLUMN id SET DEFAULT nextval('public.characteristics_calculatedcharacteristic_id_seq'::regclass);


--
-- Name: characteristics_supportedcharacteristic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_supportedcharacteristic ALTER COLUMN id SET DEFAULT nextval('public.characteristics_supportedcharacteristic_id_seq'::regclass);


--
-- Name: characteristics_supportedcharacteristic_subcharacteristics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_supportedcharacteristic_subcharacteristics ALTER COLUMN id SET DEFAULT nextval('public.characteristics_supportedcharacteristic_subcharacteristi_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: goals_goal id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals_goal ALTER COLUMN id SET DEFAULT nextval('public.goals_goal_id_seq'::regclass);


--
-- Name: measures_calculatedmeasure id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_calculatedmeasure ALTER COLUMN id SET DEFAULT nextval('public.measures_calculatedmeasure_id_seq'::regclass);


--
-- Name: measures_supportedmeasure id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_supportedmeasure ALTER COLUMN id SET DEFAULT nextval('public.measures_supportedmeasure_id_seq'::regclass);


--
-- Name: measures_supportedmeasure_metrics id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_supportedmeasure_metrics ALTER COLUMN id SET DEFAULT nextval('public.measures_supportedmeasure_metrics_id_seq'::regclass);


--
-- Name: metrics_collectedmetric id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_collectedmetric ALTER COLUMN id SET DEFAULT nextval('public.metrics_collectedmetric_id_seq'::regclass);


--
-- Name: metrics_supportedmetric id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_supportedmetric ALTER COLUMN id SET DEFAULT nextval('public.metrics_supportedmetric_id_seq'::regclass);


--
-- Name: organizations_organization id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_organization ALTER COLUMN id SET DEFAULT nextval('public.organizations_organization_id_seq'::regclass);


--
-- Name: organizations_organization_members id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_organization_members ALTER COLUMN id SET DEFAULT nextval('public.organizations_organization_members_id_seq'::regclass);


--
-- Name: organizations_product id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_product ALTER COLUMN id SET DEFAULT nextval('public.organizations_product_id_seq'::regclass);


--
-- Name: organizations_repository id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_repository ALTER COLUMN id SET DEFAULT nextval('public.organizations_repository_id_seq'::regclass);


--
-- Name: pre_configs_preconfig id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pre_configs_preconfig ALTER COLUMN id SET DEFAULT nextval('public.pre_configs_preconfig_id_seq'::regclass);


--
-- Name: socialaccount_socialaccount id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialaccount ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialaccount_id_seq'::regclass);


--
-- Name: socialaccount_socialapp id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_id_seq'::regclass);


--
-- Name: socialaccount_socialapp_sites id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialapp_sites_id_seq'::regclass);


--
-- Name: socialaccount_socialtoken id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken ALTER COLUMN id SET DEFAULT nextval('public.socialaccount_socialtoken_id_seq'::regclass);


--
-- Name: sqc_sqc id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sqc_sqc ALTER COLUMN id SET DEFAULT nextval('public.sqc_sqc_id_seq'::regclass);


--
-- Name: subcharacteristics_calculatedsubcharacteristic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_calculatedsubcharacteristic ALTER COLUMN id SET DEFAULT nextval('public.subcharacteristics_calculatedsubcharacteristic_id_seq'::regclass);


--
-- Name: subcharacteristics_supportedsubcharacteristic id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_supportedsubcharacteristic ALTER COLUMN id SET DEFAULT nextval('public.subcharacteristics_supportedsubcharacteristic_id_seq'::regclass);


--
-- Name: subcharacteristics_supportedsubcharacteristic_measures id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_supportedsubcharacteristic_measures ALTER COLUMN id SET DEFAULT nextval('public.subcharacteristics_supportedsubcharacteristic_measures_id_seq'::regclass);


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
\.
COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM '$$PATH$$/3762.dat';

--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.
COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM '$$PATH$$/3764.dat';

--
-- Data for Name: accounts_customuser; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts_customuser (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.accounts_customuser (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/3756.dat';

--
-- Data for Name: accounts_customuser_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts_customuser_groups (id, customuser_id, group_id) FROM stdin;
\.
COPY public.accounts_customuser_groups (id, customuser_id, group_id) FROM '$$PATH$$/3758.dat';

--
-- Data for Name: accounts_customuser_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts_customuser_user_permissions (id, customuser_id, permission_id) FROM stdin;
\.
COPY public.accounts_customuser_user_permissions (id, customuser_id, permission_id) FROM '$$PATH$$/3760.dat';

--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3752.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3754.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3750.dat';

--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
\.
COPY public.authtoken_token (key, created, user_id) FROM '$$PATH$$/3767.dat';

--
-- Data for Name: characteristics_calculatedcharacteristic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.characteristics_calculatedcharacteristic (id, value, created_at, characteristic_id, repository_id) FROM stdin;
\.
COPY public.characteristics_calculatedcharacteristic (id, value, created_at, characteristic_id, repository_id) FROM '$$PATH$$/3797.dat';

--
-- Data for Name: characteristics_supportedcharacteristic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.characteristics_supportedcharacteristic (id, name, key, description) FROM stdin;
\.
COPY public.characteristics_supportedcharacteristic (id, name, key, description) FROM '$$PATH$$/3793.dat';

--
-- Data for Name: characteristics_supportedcharacteristic_subcharacteristics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.characteristics_supportedcharacteristic_subcharacteristics (id, supportedcharacteristic_id, supportedsubcharacteristic_id) FROM stdin;
\.
COPY public.characteristics_supportedcharacteristic_subcharacteristics (id, supportedcharacteristic_id, supportedsubcharacteristic_id) FROM '$$PATH$$/3795.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3766.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3748.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3746.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3802.dat';

--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_site (id, domain, name) FROM stdin;
\.
COPY public.django_site (id, domain, name) FROM '$$PATH$$/3804.dat';

--
-- Data for Name: goals_goal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.goals_goal (id, created_at, start_at, end_at, release_name, data, product_id) FROM stdin;
\.
COPY public.goals_goal (id, created_at, start_at, end_at, release_name, data, product_id) FROM '$$PATH$$/3799.dat';

--
-- Data for Name: measures_calculatedmeasure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.measures_calculatedmeasure (id, value, created_at, measure_id, repository_id) FROM stdin;
\.
COPY public.measures_calculatedmeasure (id, value, created_at, measure_id, repository_id) FROM '$$PATH$$/3785.dat';

--
-- Data for Name: measures_supportedmeasure; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.measures_supportedmeasure (id, key, name, description) FROM stdin;
\.
COPY public.measures_supportedmeasure (id, key, name, description) FROM '$$PATH$$/3781.dat';

--
-- Data for Name: measures_supportedmeasure_metrics; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.measures_supportedmeasure_metrics (id, supportedmeasure_id, supportedmetric_id) FROM stdin;
\.
COPY public.measures_supportedmeasure_metrics (id, supportedmeasure_id, supportedmetric_id) FROM '$$PATH$$/3783.dat';

--
-- Data for Name: metrics_collectedmetric; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.metrics_collectedmetric (id, value, path, qualifier, dynamic_key, created_at, metric_id, repository_id) FROM stdin;
\.
COPY public.metrics_collectedmetric (id, value, path, qualifier, dynamic_key, created_at, metric_id, repository_id) FROM '$$PATH$$/3779.dat';

--
-- Data for Name: metrics_supportedmetric; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.metrics_supportedmetric (id, key, metric_type, name, description) FROM stdin;
\.
COPY public.metrics_supportedmetric (id, key, metric_type, name, description) FROM '$$PATH$$/3777.dat';

--
-- Data for Name: organizations_organization; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations_organization (id, name, key, description) FROM stdin;
\.
COPY public.organizations_organization (id, name, key, description) FROM '$$PATH$$/3769.dat';

--
-- Data for Name: organizations_organization_members; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations_organization_members (id, organization_id, customuser_id) FROM stdin;
\.
COPY public.organizations_organization_members (id, organization_id, customuser_id) FROM '$$PATH$$/3771.dat';

--
-- Data for Name: organizations_product; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations_product (id, name, key, description, organization_id) FROM stdin;
\.
COPY public.organizations_product (id, name, key, description, organization_id) FROM '$$PATH$$/3773.dat';

--
-- Data for Name: organizations_repository; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.organizations_repository (id, name, key, description, product_id) FROM stdin;
\.
COPY public.organizations_repository (id, name, key, description, product_id) FROM '$$PATH$$/3775.dat';

--
-- Data for Name: pre_configs_preconfig; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pre_configs_preconfig (id, created_at, name, data, product_id) FROM stdin;
\.
COPY public.pre_configs_preconfig (id, created_at, name, data, product_id) FROM '$$PATH$$/3801.dat';

--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.
COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM '$$PATH$$/3806.dat';

--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM stdin;
\.
COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key) FROM '$$PATH$$/3808.dat';

--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.
COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM '$$PATH$$/3810.dat';

--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.
COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM '$$PATH$$/3812.dat';

--
-- Data for Name: sqc_sqc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sqc_sqc (id, value, created_at, repository_id) FROM stdin;
\.
COPY public.sqc_sqc (id, value, created_at, repository_id) FROM '$$PATH$$/3814.dat';

--
-- Data for Name: subcharacteristics_calculatedsubcharacteristic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subcharacteristics_calculatedsubcharacteristic (id, value, created_at, repository_id, subcharacteristic_id) FROM stdin;
\.
COPY public.subcharacteristics_calculatedsubcharacteristic (id, value, created_at, repository_id, subcharacteristic_id) FROM '$$PATH$$/3791.dat';

--
-- Data for Name: subcharacteristics_supportedsubcharacteristic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subcharacteristics_supportedsubcharacteristic (id, name, key, description) FROM stdin;
\.
COPY public.subcharacteristics_supportedsubcharacteristic (id, name, key, description) FROM '$$PATH$$/3787.dat';

--
-- Data for Name: subcharacteristics_supportedsubcharacteristic_measures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subcharacteristics_supportedsubcharacteristic_measures (id, supportedsubcharacteristic_id, supportedmeasure_id) FROM stdin;
\.
COPY public.subcharacteristics_supportedsubcharacteristic_measures (id, supportedsubcharacteristic_id, supportedmeasure_id) FROM '$$PATH$$/3789.dat';

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, false);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: accounts_customuser_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_customuser_groups_id_seq', 1, false);


--
-- Name: accounts_customuser_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_customuser_id_seq', 1, true);


--
-- Name: accounts_customuser_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.accounts_customuser_user_permissions_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 112, true);


--
-- Name: characteristics_calculatedcharacteristic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.characteristics_calculatedcharacteristic_id_seq', 12, true);


--
-- Name: characteristics_supportedcharacteristic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.characteristics_supportedcharacteristic_id_seq', 3, true);


--
-- Name: characteristics_supportedcharacteristic_subcharacteristi_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.characteristics_supportedcharacteristic_subcharacteristi_id_seq', 3, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 28, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 39, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: goals_goal_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.goals_goal_id_seq', 1, false);


--
-- Name: measures_calculatedmeasure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.measures_calculatedmeasure_id_seq', 36, true);


--
-- Name: measures_supportedmeasure_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.measures_supportedmeasure_id_seq', 7, true);


--
-- Name: measures_supportedmeasure_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.measures_supportedmeasure_metrics_id_seq', 11, true);


--
-- Name: metrics_collectedmetric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.metrics_collectedmetric_id_seq', 5255, true);


--
-- Name: metrics_supportedmetric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.metrics_supportedmetric_id_seq', 112, true);


--
-- Name: organizations_organization_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_organization_id_seq', 1, true);


--
-- Name: organizations_organization_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_organization_members_id_seq', 1, false);


--
-- Name: organizations_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_product_id_seq', 1, true);


--
-- Name: organizations_repository_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.organizations_repository_id_seq', 4, true);


--
-- Name: pre_configs_preconfig_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pre_configs_preconfig_id_seq', 1, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: sqc_sqc_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sqc_sqc_id_seq', 6, true);


--
-- Name: subcharacteristics_calculatedsubcharacteristic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subcharacteristics_calculatedsubcharacteristic_id_seq', 12, true);


--
-- Name: subcharacteristics_supportedsubcharacteristic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subcharacteristics_supportedsubcharacteristic_id_seq', 3, true);


--
-- Name: subcharacteristics_supportedsubcharacteristic_measures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subcharacteristics_supportedsubcharacteristic_measures_id_seq', 7, true);


--
-- Name: account_emailaddress account_emailaddress_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_email_key UNIQUE (email);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: accounts_customuser accounts_customuser_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser
    ADD CONSTRAINT accounts_customuser_email_key UNIQUE (email);


--
-- Name: accounts_customuser_groups accounts_customuser_groups_customuser_id_group_id_c074bdcb_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_groups
    ADD CONSTRAINT accounts_customuser_groups_customuser_id_group_id_c074bdcb_uniq UNIQUE (customuser_id, group_id);


--
-- Name: accounts_customuser_groups accounts_customuser_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_groups
    ADD CONSTRAINT accounts_customuser_groups_pkey PRIMARY KEY (id);


--
-- Name: accounts_customuser accounts_customuser_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser
    ADD CONSTRAINT accounts_customuser_pkey PRIMARY KEY (id);


--
-- Name: accounts_customuser_user_permissions accounts_customuser_user_customuser_id_permission_9632a709_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_user_permissions
    ADD CONSTRAINT accounts_customuser_user_customuser_id_permission_9632a709_uniq UNIQUE (customuser_id, permission_id);


--
-- Name: accounts_customuser_user_permissions accounts_customuser_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_user_permissions
    ADD CONSTRAINT accounts_customuser_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: accounts_customuser accounts_customuser_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser
    ADD CONSTRAINT accounts_customuser_username_key UNIQUE (username);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: characteristics_calculatedcharacteristic characteristics_calculatedcharacteristic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_calculatedcharacteristic
    ADD CONSTRAINT characteristics_calculatedcharacteristic_pkey PRIMARY KEY (id);


--
-- Name: characteristics_supportedcharacteristic_subcharacteristics characteristics_supporte_supportedcharacteristic__9118643a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_supportedcharacteristic_subcharacteristics
    ADD CONSTRAINT characteristics_supporte_supportedcharacteristic__9118643a_uniq UNIQUE (supportedcharacteristic_id, supportedsubcharacteristic_id);


--
-- Name: characteristics_supportedcharacteristic characteristics_supportedcharacteristic_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_supportedcharacteristic
    ADD CONSTRAINT characteristics_supportedcharacteristic_key_key UNIQUE (key);


--
-- Name: characteristics_supportedcharacteristic characteristics_supportedcharacteristic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_supportedcharacteristic
    ADD CONSTRAINT characteristics_supportedcharacteristic_pkey PRIMARY KEY (id);


--
-- Name: characteristics_supportedcharacteristic_subcharacteristics characteristics_supportedcharacteristic_subcharacteristics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_supportedcharacteristic_subcharacteristics
    ADD CONSTRAINT characteristics_supportedcharacteristic_subcharacteristics_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: goals_goal goals_goal_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals_goal
    ADD CONSTRAINT goals_goal_pkey PRIMARY KEY (id);


--
-- Name: measures_calculatedmeasure measures_calculatedmeasure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_calculatedmeasure
    ADD CONSTRAINT measures_calculatedmeasure_pkey PRIMARY KEY (id);


--
-- Name: measures_supportedmeasure_metrics measures_supportedmeasur_supportedmeasure_id_supp_912fa6d6_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_supportedmeasure_metrics
    ADD CONSTRAINT measures_supportedmeasur_supportedmeasure_id_supp_912fa6d6_uniq UNIQUE (supportedmeasure_id, supportedmetric_id);


--
-- Name: measures_supportedmeasure measures_supportedmeasure_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_supportedmeasure
    ADD CONSTRAINT measures_supportedmeasure_key_key UNIQUE (key);


--
-- Name: measures_supportedmeasure_metrics measures_supportedmeasure_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_supportedmeasure_metrics
    ADD CONSTRAINT measures_supportedmeasure_metrics_pkey PRIMARY KEY (id);


--
-- Name: measures_supportedmeasure measures_supportedmeasure_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_supportedmeasure
    ADD CONSTRAINT measures_supportedmeasure_pkey PRIMARY KEY (id);


--
-- Name: metrics_collectedmetric metrics_collectedmetric_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_collectedmetric
    ADD CONSTRAINT metrics_collectedmetric_pkey PRIMARY KEY (id);


--
-- Name: metrics_supportedmetric metrics_supportedmetric_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_supportedmetric
    ADD CONSTRAINT metrics_supportedmetric_key_key UNIQUE (key);


--
-- Name: metrics_supportedmetric metrics_supportedmetric_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_supportedmetric
    ADD CONSTRAINT metrics_supportedmetric_pkey PRIMARY KEY (id);


--
-- Name: organizations_organization_members organizations_organizati_organization_id_customus_4e292f2b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_organization_members
    ADD CONSTRAINT organizations_organizati_organization_id_customus_4e292f2b_uniq UNIQUE (organization_id, customuser_id);


--
-- Name: organizations_organization organizations_organization_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_organization
    ADD CONSTRAINT organizations_organization_key_key UNIQUE (key);


--
-- Name: organizations_organization_members organizations_organization_members_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_organization_members
    ADD CONSTRAINT organizations_organization_members_pkey PRIMARY KEY (id);


--
-- Name: organizations_organization organizations_organization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_organization
    ADD CONSTRAINT organizations_organization_pkey PRIMARY KEY (id);


--
-- Name: organizations_product organizations_product_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_product
    ADD CONSTRAINT organizations_product_key_key UNIQUE (key);


--
-- Name: organizations_product organizations_product_key_organization_id_78148dd5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_product
    ADD CONSTRAINT organizations_product_key_organization_id_78148dd5_uniq UNIQUE (key, organization_id);


--
-- Name: organizations_product organizations_product_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_product
    ADD CONSTRAINT organizations_product_pkey PRIMARY KEY (id);


--
-- Name: organizations_repository organizations_repository_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_repository
    ADD CONSTRAINT organizations_repository_key_key UNIQUE (key);


--
-- Name: organizations_repository organizations_repository_key_product_id_5ccfb445_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_repository
    ADD CONSTRAINT organizations_repository_key_product_id_5ccfb445_uniq UNIQUE (key, product_id);


--
-- Name: organizations_repository organizations_repository_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_repository
    ADD CONSTRAINT organizations_repository_pkey PRIMARY KEY (id);


--
-- Name: pre_configs_preconfig pre_configs_preconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pre_configs_preconfig
    ADD CONSTRAINT pre_configs_preconfig_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: sqc_sqc sqc_sqc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sqc_sqc
    ADD CONSTRAINT sqc_sqc_pkey PRIMARY KEY (id);


--
-- Name: subcharacteristics_calculatedsubcharacteristic subcharacteristics_calculatedsubcharacteristic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_calculatedsubcharacteristic
    ADD CONSTRAINT subcharacteristics_calculatedsubcharacteristic_pkey PRIMARY KEY (id);


--
-- Name: subcharacteristics_supportedsubcharacteristic_measures subcharacteristics_suppo_supportedsubcharacterist_cea8f07c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_supportedsubcharacteristic_measures
    ADD CONSTRAINT subcharacteristics_suppo_supportedsubcharacterist_cea8f07c_uniq UNIQUE (supportedsubcharacteristic_id, supportedmeasure_id);


--
-- Name: subcharacteristics_supportedsubcharacteristic subcharacteristics_supportedsubcharacteristic_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_supportedsubcharacteristic
    ADD CONSTRAINT subcharacteristics_supportedsubcharacteristic_key_key UNIQUE (key);


--
-- Name: subcharacteristics_supportedsubcharacteristic_measures subcharacteristics_supportedsubcharacteristic_measures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_supportedsubcharacteristic_measures
    ADD CONSTRAINT subcharacteristics_supportedsubcharacteristic_measures_pkey PRIMARY KEY (id);


--
-- Name: subcharacteristics_supportedsubcharacteristic subcharacteristics_supportedsubcharacteristic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_supportedsubcharacteristic
    ADD CONSTRAINT subcharacteristics_supportedsubcharacteristic_pkey PRIMARY KEY (id);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: accounts_customuser_email_4fd8e7ce_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_customuser_email_4fd8e7ce_like ON public.accounts_customuser USING btree (email varchar_pattern_ops);


--
-- Name: accounts_customuser_groups_customuser_id_bc55088e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_customuser_groups_customuser_id_bc55088e ON public.accounts_customuser_groups USING btree (customuser_id);


--
-- Name: accounts_customuser_groups_group_id_86ba5f9e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_customuser_groups_group_id_86ba5f9e ON public.accounts_customuser_groups USING btree (group_id);


--
-- Name: accounts_customuser_user_permissions_customuser_id_0deaefae; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_customuser_user_permissions_customuser_id_0deaefae ON public.accounts_customuser_user_permissions USING btree (customuser_id);


--
-- Name: accounts_customuser_user_permissions_permission_id_aea3d0e5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_customuser_user_permissions_permission_id_aea3d0e5 ON public.accounts_customuser_user_permissions USING btree (permission_id);


--
-- Name: accounts_customuser_username_722f3555_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX accounts_customuser_username_722f3555_like ON public.accounts_customuser USING btree (username varchar_pattern_ops);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: characteristics_calculated_characteristic_id_9d0c1fd4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX characteristics_calculated_characteristic_id_9d0c1fd4 ON public.characteristics_calculatedcharacteristic USING btree (characteristic_id);


--
-- Name: characteristics_calculatedcharacteristic_repository_id_c5e0c707; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX characteristics_calculatedcharacteristic_repository_id_c5e0c707 ON public.characteristics_calculatedcharacteristic USING btree (repository_id);


--
-- Name: characteristics_supportedc_supportedcharacteristic_id_4692ee24; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX characteristics_supportedc_supportedcharacteristic_id_4692ee24 ON public.characteristics_supportedcharacteristic_subcharacteristics USING btree (supportedcharacteristic_id);


--
-- Name: characteristics_supportedc_supportedsubcharacteristic_d594d50d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX characteristics_supportedc_supportedsubcharacteristic_d594d50d ON public.characteristics_supportedcharacteristic_subcharacteristics USING btree (supportedsubcharacteristic_id);


--
-- Name: characteristics_supportedcharacteristic_key_9c5f4007_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX characteristics_supportedcharacteristic_key_9c5f4007_like ON public.characteristics_supportedcharacteristic USING btree (key varchar_pattern_ops);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: goals_goal_product_id_3f671655; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX goals_goal_product_id_3f671655 ON public.goals_goal USING btree (product_id);


--
-- Name: measures_calculatedmeasure_measure_id_a176a529; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX measures_calculatedmeasure_measure_id_a176a529 ON public.measures_calculatedmeasure USING btree (measure_id);


--
-- Name: measures_calculatedmeasure_repository_id_29ecb3d8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX measures_calculatedmeasure_repository_id_29ecb3d8 ON public.measures_calculatedmeasure USING btree (repository_id);


--
-- Name: measures_supportedmeasure_key_b8d9da8f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX measures_supportedmeasure_key_b8d9da8f_like ON public.measures_supportedmeasure USING btree (key varchar_pattern_ops);


--
-- Name: measures_supportedmeasure_metrics_supportedmeasure_id_913c2454; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX measures_supportedmeasure_metrics_supportedmeasure_id_913c2454 ON public.measures_supportedmeasure_metrics USING btree (supportedmeasure_id);


--
-- Name: measures_supportedmeasure_metrics_supportedmetric_id_e6f200b5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX measures_supportedmeasure_metrics_supportedmetric_id_e6f200b5 ON public.measures_supportedmeasure_metrics USING btree (supportedmetric_id);


--
-- Name: metrics_collectedmetric_metric_id_962e100e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX metrics_collectedmetric_metric_id_962e100e ON public.metrics_collectedmetric USING btree (metric_id);


--
-- Name: metrics_collectedmetric_repository_id_ea9a88be; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX metrics_collectedmetric_repository_id_ea9a88be ON public.metrics_collectedmetric USING btree (repository_id);


--
-- Name: metrics_supportedmetric_key_75410025_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX metrics_supportedmetric_key_75410025_like ON public.metrics_supportedmetric USING btree (key varchar_pattern_ops);


--
-- Name: organizations_organization_key_deac3412_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizations_organization_key_deac3412_like ON public.organizations_organization USING btree (key varchar_pattern_ops);


--
-- Name: organizations_organization_members_customuser_id_1f2abab7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizations_organization_members_customuser_id_1f2abab7 ON public.organizations_organization_members USING btree (customuser_id);


--
-- Name: organizations_organization_members_organization_id_e38ecea8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizations_organization_members_organization_id_e38ecea8 ON public.organizations_organization_members USING btree (organization_id);


--
-- Name: organizations_product_key_d986b824_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizations_product_key_d986b824_like ON public.organizations_product USING btree (key varchar_pattern_ops);


--
-- Name: organizations_product_organization_id_bd3a2354; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizations_product_organization_id_bd3a2354 ON public.organizations_product USING btree (organization_id);


--
-- Name: organizations_repository_key_e3e61251_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizations_repository_key_e3e61251_like ON public.organizations_repository USING btree (key varchar_pattern_ops);


--
-- Name: organizations_repository_product_id_4bf98ecc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organizations_repository_product_id_4bf98ecc ON public.organizations_repository USING btree (product_id);


--
-- Name: pre_configs_preconfig_product_id_5a92e90a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pre_configs_preconfig_product_id_5a92e90a ON public.pre_configs_preconfig USING btree (product_id);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: sqc_sqc_repository_id_e0c572d0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX sqc_sqc_repository_id_e0c572d0 ON public.sqc_sqc USING btree (repository_id);


--
-- Name: subcharacteristics_calcula_repository_id_ed62dbe4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subcharacteristics_calcula_repository_id_ed62dbe4 ON public.subcharacteristics_calculatedsubcharacteristic USING btree (repository_id);


--
-- Name: subcharacteristics_calcula_subcharacteristic_id_5d71309c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subcharacteristics_calcula_subcharacteristic_id_5d71309c ON public.subcharacteristics_calculatedsubcharacteristic USING btree (subcharacteristic_id);


--
-- Name: subcharacteristics_support_supportedmeasure_id_b9971d98; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subcharacteristics_support_supportedmeasure_id_b9971d98 ON public.subcharacteristics_supportedsubcharacteristic_measures USING btree (supportedmeasure_id);


--
-- Name: subcharacteristics_support_supportedsubcharacteristic_e4b5850d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subcharacteristics_support_supportedsubcharacteristic_e4b5850d ON public.subcharacteristics_supportedsubcharacteristic_measures USING btree (supportedsubcharacteristic_id);


--
-- Name: subcharacteristics_supportedsubcharacteristic_key_bf430c02_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX subcharacteristics_supportedsubcharacteristic_key_bf430c02_like ON public.subcharacteristics_supportedsubcharacteristic USING btree (key varchar_pattern_ops);


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk_accounts_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk_accounts_customuser_id FOREIGN KEY (user_id) REFERENCES public.accounts_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_customuser_user_permissions accounts_customuser__customuser_id_0deaefae_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_user_permissions
    ADD CONSTRAINT accounts_customuser__customuser_id_0deaefae_fk_accounts_ FOREIGN KEY (customuser_id) REFERENCES public.accounts_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_customuser_groups accounts_customuser__customuser_id_bc55088e_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_groups
    ADD CONSTRAINT accounts_customuser__customuser_id_bc55088e_fk_accounts_ FOREIGN KEY (customuser_id) REFERENCES public.accounts_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_customuser_user_permissions accounts_customuser__permission_id_aea3d0e5_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_user_permissions
    ADD CONSTRAINT accounts_customuser__permission_id_aea3d0e5_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: accounts_customuser_groups accounts_customuser_groups_group_id_86ba5f9e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts_customuser_groups
    ADD CONSTRAINT accounts_customuser_groups_group_id_86ba5f9e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_accounts_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_accounts_customuser_id FOREIGN KEY (user_id) REFERENCES public.accounts_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: characteristics_calculatedcharacteristic characteristics_calc_characteristic_id_9d0c1fd4_fk_character; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_calculatedcharacteristic
    ADD CONSTRAINT characteristics_calc_characteristic_id_9d0c1fd4_fk_character FOREIGN KEY (characteristic_id) REFERENCES public.characteristics_supportedcharacteristic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: characteristics_calculatedcharacteristic characteristics_calc_repository_id_c5e0c707_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_calculatedcharacteristic
    ADD CONSTRAINT characteristics_calc_repository_id_c5e0c707_fk_organizat FOREIGN KEY (repository_id) REFERENCES public.organizations_repository(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: characteristics_supportedcharacteristic_subcharacteristics characteristics_supp_supportedcharacteris_4692ee24_fk_character; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_supportedcharacteristic_subcharacteristics
    ADD CONSTRAINT characteristics_supp_supportedcharacteris_4692ee24_fk_character FOREIGN KEY (supportedcharacteristic_id) REFERENCES public.characteristics_supportedcharacteristic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: characteristics_supportedcharacteristic_subcharacteristics characteristics_supp_supportedsubcharacte_d594d50d_fk_subcharac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.characteristics_supportedcharacteristic_subcharacteristics
    ADD CONSTRAINT characteristics_supp_supportedsubcharacte_d594d50d_fk_subcharac FOREIGN KEY (supportedsubcharacteristic_id) REFERENCES public.subcharacteristics_supportedsubcharacteristic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_accounts_customuser_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_accounts_customuser_id FOREIGN KEY (user_id) REFERENCES public.accounts_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: goals_goal goals_goal_product_id_3f671655_fk_organizations_product_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.goals_goal
    ADD CONSTRAINT goals_goal_product_id_3f671655_fk_organizations_product_id FOREIGN KEY (product_id) REFERENCES public.organizations_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measures_calculatedmeasure measures_calculatedm_measure_id_a176a529_fk_measures_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_calculatedmeasure
    ADD CONSTRAINT measures_calculatedm_measure_id_a176a529_fk_measures_ FOREIGN KEY (measure_id) REFERENCES public.measures_supportedmeasure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measures_calculatedmeasure measures_calculatedm_repository_id_29ecb3d8_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_calculatedmeasure
    ADD CONSTRAINT measures_calculatedm_repository_id_29ecb3d8_fk_organizat FOREIGN KEY (repository_id) REFERENCES public.organizations_repository(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measures_supportedmeasure_metrics measures_supportedme_supportedmeasure_id_913c2454_fk_measures_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_supportedmeasure_metrics
    ADD CONSTRAINT measures_supportedme_supportedmeasure_id_913c2454_fk_measures_ FOREIGN KEY (supportedmeasure_id) REFERENCES public.measures_supportedmeasure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: measures_supportedmeasure_metrics measures_supportedme_supportedmetric_id_e6f200b5_fk_metrics_s; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.measures_supportedmeasure_metrics
    ADD CONSTRAINT measures_supportedme_supportedmetric_id_e6f200b5_fk_metrics_s FOREIGN KEY (supportedmetric_id) REFERENCES public.metrics_supportedmetric(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: metrics_collectedmetric metrics_collectedmet_metric_id_962e100e_fk_metrics_s; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_collectedmetric
    ADD CONSTRAINT metrics_collectedmet_metric_id_962e100e_fk_metrics_s FOREIGN KEY (metric_id) REFERENCES public.metrics_supportedmetric(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: metrics_collectedmetric metrics_collectedmet_repository_id_ea9a88be_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.metrics_collectedmetric
    ADD CONSTRAINT metrics_collectedmet_repository_id_ea9a88be_fk_organizat FOREIGN KEY (repository_id) REFERENCES public.organizations_repository(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organizations_organization_members organizations_organi_customuser_id_1f2abab7_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_organization_members
    ADD CONSTRAINT organizations_organi_customuser_id_1f2abab7_fk_accounts_ FOREIGN KEY (customuser_id) REFERENCES public.accounts_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organizations_organization_members organizations_organi_organization_id_e38ecea8_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_organization_members
    ADD CONSTRAINT organizations_organi_organization_id_e38ecea8_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organizations_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organizations_product organizations_produc_organization_id_bd3a2354_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_product
    ADD CONSTRAINT organizations_produc_organization_id_bd3a2354_fk_organizat FOREIGN KEY (organization_id) REFERENCES public.organizations_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organizations_repository organizations_reposi_product_id_4bf98ecc_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.organizations_repository
    ADD CONSTRAINT organizations_reposi_product_id_4bf98ecc_fk_organizat FOREIGN KEY (product_id) REFERENCES public.organizations_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pre_configs_preconfig pre_configs_preconfi_product_id_5a92e90a_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pre_configs_preconfig
    ADD CONSTRAINT pre_configs_preconfi_product_id_5a92e90a_fk_organizat FOREIGN KEY (product_id) REFERENCES public.organizations_product(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_social_user_id_8146e70c_fk_accounts_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_social_user_id_8146e70c_fk_accounts_ FOREIGN KEY (user_id) REFERENCES public.accounts_customuser(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sqc_sqc sqc_sqc_repository_id_e0c572d0_fk_organizations_repository_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sqc_sqc
    ADD CONSTRAINT sqc_sqc_repository_id_e0c572d0_fk_organizations_repository_id FOREIGN KEY (repository_id) REFERENCES public.organizations_repository(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subcharacteristics_calculatedsubcharacteristic subcharacteristics_c_repository_id_ed62dbe4_fk_organizat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_calculatedsubcharacteristic
    ADD CONSTRAINT subcharacteristics_c_repository_id_ed62dbe4_fk_organizat FOREIGN KEY (repository_id) REFERENCES public.organizations_repository(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subcharacteristics_calculatedsubcharacteristic subcharacteristics_c_subcharacteristic_id_5d71309c_fk_subcharac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_calculatedsubcharacteristic
    ADD CONSTRAINT subcharacteristics_c_subcharacteristic_id_5d71309c_fk_subcharac FOREIGN KEY (subcharacteristic_id) REFERENCES public.subcharacteristics_supportedsubcharacteristic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subcharacteristics_supportedsubcharacteristic_measures subcharacteristics_s_supportedmeasure_id_b9971d98_fk_measures_; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_supportedsubcharacteristic_measures
    ADD CONSTRAINT subcharacteristics_s_supportedmeasure_id_b9971d98_fk_measures_ FOREIGN KEY (supportedmeasure_id) REFERENCES public.measures_supportedmeasure(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: subcharacteristics_supportedsubcharacteristic_measures subcharacteristics_s_supportedsubcharacte_e4b5850d_fk_subcharac; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subcharacteristics_supportedsubcharacteristic_measures
    ADD CONSTRAINT subcharacteristics_s_supportedsubcharacte_e4b5850d_fk_subcharac FOREIGN KEY (supportedsubcharacteristic_id) REFERENCES public.subcharacteristics_supportedsubcharacteristic(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

